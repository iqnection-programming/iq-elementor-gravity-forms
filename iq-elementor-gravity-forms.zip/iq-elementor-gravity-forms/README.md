# Elementor Gravity Forms WordPress Plugin

** This plugin is not intended to replace the default Gravity Forms styling, it just adds overrides for basic colors, borders, sizes, etc.

## Installation
- Install Elementor and Gravity Forms on your WordPress site
- Download this package
- Navigate to your WordPress plugin manager
- Click Add New, then Upload
- Select the iq-elementor-gravity-forms.zip file from this package to upload
- Once installed, activate the plugin


### Usage
A new area will be available under the Elementor Site Settings to set the default styling for Gravity Forms.


